﻿using events.tac.local.Areas.Importer.Models;
using Newtonsoft.Json;
using Sitecore.Data.Items;
using Sitecore.SecurityModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace events.tac.local.Areas.Importer.Controllers
{
    public class EventsController : Controller
    {
        // GET: Importer/Events
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase file, string parentPath)
        {
            IEnumerable<Event> events = null;
            string message = null;
            using (var reader = new StreamReader(file.InputStream))
            {
                var contents = reader.ReadToEnd(); try { events = JsonConvert.DeserializeObject<IEnumerable<Event>>(contents); }
                catch (Exception ex)
                {
                    throw;
                }
            }
                var database = Sitecore.Configuration.Factory.GetDatabase("master");
                var parent = Sitecore.Context.Database.GetItem(parentPath);
                Sitecore.Data.TemplateID eventTemplateId = new Sitecore.Data.TemplateID(new Sitecore.Data.ID("{AB86861A-6030-46C5-B394-E8F99E8B87DB}"));
                using (new SecurityDisabler())
                {
                    foreach(var i in events)
                    {
                        string name = ItemUtil.ProposeValidItemName(i.Name);
                        Item item = parent.Add(name, eventTemplateId);
                        item.Editing.BeginEdit();
                        item["ContentHeading"] = i.ContentHeading;
                        item.Editing.EndEdit();


                    }


                }
            return View();
                  
            }

        }
    }
