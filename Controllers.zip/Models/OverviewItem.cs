﻿using System.Web;

namespace events.tac.local.Models
{
    public class OverviewItem
    {
        public HtmlString ContentHeading { get; set; }
        public HtmlString DecorationBanner { get; set; }
        public string URL { get; set; }
    }
}