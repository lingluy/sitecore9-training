﻿namespace events.tac.local.Models
{
    public class NavigationItem : Sitecore.Mvc.Presentation.RenderingModel
    {
        public string Title { get; set; }
        public string URL { get; set; }
        public bool Active { get; set; }
    }
}