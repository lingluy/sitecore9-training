﻿using events.tac.local.Models;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Mvc.Presentation;
using events.tac.local.Models;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using System.Linq;


namespace events.tac.local.Business
{
    public class EventsProvider
    {
        public EventList getEventsList(int pageNo)
        {
            var dbName = Sitecore.Context.Database.Name.ToLower();
            var indexName = string.Format("events_{0}_index", dbName);
            var index = Sitecore.ContentSearch.ContentSearchManager.GetIndex(indexName);
            using (var context = index.CreateSearchContext())
            {
                var results =
                     context.GetQueryable<EventDetails>()
                        .Where(i => i.Paths.Contains(RenderingContext.Current.ContextItem.ID))
                        .Where(i => i.Language == RenderingContext.Current.ContextItem.Language.Name)
                        .Page(pageNo, 4)
                        .GetResults();

                return new EventList()
                {
                    Events = results.Hits.Select(h => h.Document).ToArray(),
                    PageSize = 4,
                    TotalResultCount = results.TotalSearchResults
                };
            }
        }

    }
}

  